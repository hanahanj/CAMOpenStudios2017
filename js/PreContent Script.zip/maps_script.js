
$(document).ready(function(){

	// THIS IS FOR A PURELY DEFAULT MAP//

	// function initialize() { 
	// 	var mapCanvas = document.getElementById('map-canvas');
	// 	var mapOptions = {
	// 		center: new google.maps.LatLng(38.2, -90),
	// 		zoom: 9,
	// 		mapTypeId: google.maps.MapTypeId.ROADMAP
	// 	}
	// 	var map = new google.maps.Map(mapCanvas, mapOptions)


	// }

// Dani edits begin. Shes the best and figured how to make a styled map!


// Set the styles for the styled map here 

function initialize() {

	  var styles = [
  {
    // stylers: [ 
    // { hue: "#FF0000" },
    // { saturation: 25 }
    // ]
  },{
    featureType: "road", 
    elementType: "geometry",
    stylers: [
    { lightness: 250 },
    { visibility: "simplified" }
    ]
  },{
    featureType: "road",
    elementType: "labels",
    stylers: [
         //Turns off road labels. 
         { visibility: "off" }
         ]
     }
     ];

		  // Create a new StyledMapType object, passing it the array of styles,
		  // as well as the name to be displayed on the map type control.
		  var styledMap = new google.maps.StyledMapType(styles,
		  	{name: "Styled Map"});

		  // Create a map object, and include the MapTypeId to add
		  // to the map type control.

		  var mapOptions = {
		  	zoom: 9,
		  	center: new google.maps.LatLng(38.2, -90),
		  	mapTypeControlOptions: {
		  		mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
		  	}
		  };


		  var mapOptions = {
		  	zoom: 9,
		  	center: new google.maps.LatLng(38.2, -90),
		  	mapTypeControlOptions: {
		  		mapTypeIds: [google.maps.MapTypeId.SATELLITE, 'map_style_Sat']
		  	}
		  };

		  var map = new google.maps.Map(document.getElementById('map-canvas'),
		  	mapOptions);

		  //Associate the styled map with the MapTypeId and set it to display.
		  
		  map.mapTypes.set('map_style', styledMap);
		  map.mapTypes.set('map_style_Sat', styledMap);
		  map.setMapTypeId('map_style');


// // Info Window

var contentString1 = '<div id="content">'+
'<div id="siteNotice">'+
'</div>'+
'<h1 id="firstHeading" class="firstHeading">Title 1</h1>'+
'<div id="bodyContent">'+
'<p>Test 1 Test 1 Test 1</p>'
'</div>'+
'</div>';

var infowindow1 = new google.maps.InfoWindow({
	content: contentString1,
	maxWidth: 200
});


var contentString2 = '<div id="content">'+
'<div id="siteNotice">'+
'</div>'+
'<h1 id="firstHeading" class="firstHeading">Title 2</h1>'+
'<div id="bodyContent">'+
'<p>Test 2 Test 2 Test 2</p>'
'</div>'+
'</div>';

var infowindow2 = new google.maps.InfoWindow({
	content: contentString2,
	maxWidth: 200
});

var AlortonContent = '<div id="content">'+
'<div id="siteNotice">'+
'</div>'+
'<h1 id="firstHeading" class="firstHeading">Alorton</h1>'+
'<div id="bodyContent">'+
'<p>Aluminum Ore Town</p>'
'</div>'+
'</div>';

var AlortonInfo = new google.maps.InfoWindow({
	content: AlortonContent,
	maxWidth: 200
});





// // Display Markers

var myLatlng = new google.maps.LatLng(38.2, -90);
var myLatlng2 = new google.maps.LatLng(38.5, -90);
var AlortonLoc = new google.maps.LatLng(38.595764, -90.129631);



var imageMark1 = 'images/ABMarker.png';

var marker1 = new google.maps.Marker({
	position: myLatlng,
	map: map,
	icon: imageMark1,
	// animation: google.maps.Animation.DROP,
	title: 'Marker 1'
});

var marker2 = new google.maps.Marker({
	position: myLatlng2,
	map: map,
	icon: imageMark1,
	// animation: google.maps.Animation.DROP,
	title: 'Marker 2'
});

var AlortonMark = new google.maps.Marker({
	position: AlortonLoc,
	map: map,
	icon: imageMark1,
	// animation: google.maps.Animation.DROP,
	title: 'Alorton'
});
// Call Marker click to reveal correct infowindow


google.maps.event.addListener(marker1, 'mouseover', function() {
	infowindow1.open(map,marker1);
});


google.maps.event.addListener(marker2, 'mouseover', function() {
	infowindow2.open(map,marker2);
});

google.maps.event.addListener(AlortonMark, 'mouseover', function() {
	AlortonInfo.open(map,AlortonMark);
});











}


// Dani edits end.


google.maps.event.addDomListener(window, 'load', initialize);




});

